'Escribe un script que utilice un bucle for para imprimir los 
números del 1 al 5 en la terminal.'

#! /bin/bash

for (( i=1; i <= 5; i++ ))
do
  echo $i
done